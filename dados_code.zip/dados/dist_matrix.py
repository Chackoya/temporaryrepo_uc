# -*- coding: utf-8 -*-
"""
Created on Sun Oct 31 23:28:28 2021

@author: gusta
"""

#Create dist matrix:


def create_dist_matrix():
    
    dist_matrix=[]
    
    
    
    for point1 in coordinates_list:
        dist_tmp=[]
        for point2 in coordinates_list:
            if point1 == point2:
                dist_tmp.append(0)
            else:
                dist_tmp.append(calc_distance(point1,point2))
        dist_matrix.append(dist_tmp)