# -*- coding: utf-8 -*-
"""
TESTING N°2
"""
from utils import calc_distance,compute_dist_matrix
import numpy as np
import math
import json
import matplotlib.pyplot as plt
import networkx as nx


# Opening JSON file
f = open('NY69105.json',)
 
# returns JSON object as
# a dictionary
data = json.load(f)
 
print(data.keys())

print(len(data["locations"]))


scale=1
#ADD THE FIRST POINT TO X Y LISTS - THIS IS THE STARTING POINT GIVEN TO US(principal equip)

x_vals=[data["startEquipment"]["x"]]#*scale]
y_vals=[data["startEquipment"]["y"]]#*scale]

print(x_vals)

print(y_vals)
number_of_locations = len(data["locations"])
        
#print(data["locations"][0])

#CREATION OF THE LISTS X Y BASED ON THE DATA LOCATIONS OF THE REST OF THE EQUIPMENT
for i in range(number_of_locations):#len(data["locations"])):
    x_vals.append(data["locations"][i]["x"])#*scale)
    y_vals.append(data["locations"][i]["y"])#*scale)




print(len(data["locations"]))


#Create a list of lists containing the coordinates, example: [[-73.9363522, 41.1002674], [-73.9348124, 41.1010119],
# [-73.9364378, 41.0997641], [-73.9363995, 41.1000434], [-73.9363298, 41.0993414], [-73.9359398, 41.1014932]]
#

coordinates_list = []
for i in range(len(x_vals)):
    tmp = [x_vals[i] , y_vals[i] ]
    
    coordinates_list.append(tmp)

#Use coordinates_list to create the distance matrix ;
#print(coordinates_list)



#Compute the distance matrix by comparing the points

dist_matrix=compute_dist_matrix(coordinates_list)



#Create the graph G ; with nodes and edges based on the closest point with the help of the dist matrix
G = nx.Graph()
#ADD NODES FIRST
for e in range(len(dist_matrix)):
    #Add the node to the graph
    G.add_node(e, pos=(coordinates_list[e][0],coordinates_list[e][1]))

#ADD EDGES:
for e in range(len(dist_matrix)):
    #print(e)
    #print(dist_matrix[e])
    #Get the distances for the equipment "e" and sort it, take the closest one 
    dist_sorted = sorted(dist_matrix[e])
    closest_point = dist_sorted[1] # index 0 is the same point... (distance = 0 from e to e)
    #Get the index of that closest point on the dist_matrix[e] (to ref to the json file later)
    index_closest_point = dist_matrix[e].index(closest_point)
    #Add an edge between equipment of index "index_closest_point" and the equipment "e" 
    G.add_edge(e,index_closest_point)
    
        

#print(nx.is_connected(G))

pos=nx.get_node_attributes(G,'pos')
pos = nx.spring_layout(G, k=0.1051, iterations=50)
while nx.is_connected(G) is False:
    #print("pos:",pos)
    #list of sets of connected components
    connected_components = [(c) for c in sorted(nx.connected_components(G), key=len, reverse=False)]
    centroids_CC = []
    
    for i in range(len(connected_components)):
        x_tmp = 0
        y_tmp = 0
        list_tmp = list(connected_components[i])#convert the set to list to get elements
        for index in list_tmp:
            x_tmp = x_tmp + pos[index][0]
            y_tmp = y_tmp + pos[index][1]
        
        centroids_CC.append(  (x_tmp/ len(list_tmp), y_tmp / len(list_tmp)) )

    
    dist_matrix_CC=compute_dist_matrix(centroids_CC)
    
    
    
    links_CC_closest = []# [] for i in range(len(connected_components))]
    
    #print(links_CC_closest)
    
    for i in range(len(dist_matrix_CC)):
        sorted_dist_matrix_CC = sorted(dist_matrix_CC[i])
        closest_CC = sorted_dist_matrix_CC[1]
        links_CC_closest.append(dist_matrix_CC[i].index(closest_CC))
        
    #print(links_CC_closest)
    
    #print("TESTing \n")
    
    for i in range(len(links_CC_closest)):
        cc_i = list(connected_components[i] )
        
        cc_closest_to_cci = list(connected_components[links_CC_closest[i]])
        
        
        stockmin=[]    
        for elem in cc_i:
            L_tmp=[]
            for elem2 in cc_closest_to_cci:
                L_tmp.append( (dist_matrix[elem][elem2] , elem2))
                
            #stock min for the first cc
            sorted_L_tmp = sorted(L_tmp , key=lambda tup: tup[0])
            #tupple_closest = 
            stockmin.append((elem,(sorted_L_tmp[0][0] , sorted_L_tmp[0][1])))
        
        
        
        sorted_stockmin= sorted( stockmin, key=lambda tup:tup[1][0])

        closest_tuple = sorted_stockmin[0]
        G.add_edge(closest_tuple[0],     closest_tuple[1][1] )

                   
    
import pylab
pylab.figure(1,figsize=(12,12))
nx.draw(G,pos,with_labels=True)

plt.savefig("graph.png", dpi=1000)

print(nx.is_connected(G))


    
    
    
    

