# -*- coding: utf-8 -*-
"""
Created on Sun Oct 10 19:16:03 2021

@author: gusta
"""
import math
from sklearn.metrics.pairwise import haversine_distances
from math import radians
def calc_distance(p1, p2): #euclidian dist
    

    
    p1_in_radians = [radians(_) for _ in p1]
    p2_in_radians = [radians(_) for _ in p2]
    result = haversine_distances([p2_in_radians, p1_in_radians])

    result = result * 6371000/1000  # multiply by Earth radius to get kilometers
    #print("Result",result)
    res = result[0][1]
    #print("Res",res)
    #print("Eucl",math.sqrt((p1[0]-p2[0])**2+(p1[1]-p2[1])**2))
    #print()
    
    
    return res#  math.sqrt((p1[0]-p2[0])**2+(p1[1]-p2[1])**2)



def compute_dist_matrix(coordinates_list):
    dist_matrix=[]

    #Compute the distance matrix by comparing the points
    for point1 in coordinates_list:
        dist_tmp=[]
        for point2 in coordinates_list:
            if point1 == point2:
                dist_tmp.append(0)
            else:
                dist_tmp.append(calc_distance(point1,point2))
        dist_matrix.append(dist_tmp)
    
    return dist_matrix


#TODO haversin
    

def primsAlgorithm(vertices,distance_matrixadj):


    minSpanningTree_Matrix = [[0 for column in range(vertices)] for row in range(vertices)]
 
    #infinte nb
    positiveInf = float('inf')
    
    # This is a list showing which vertices are already selected, so we don't pick the same vertex twice and we can actually know when stop looking
    selectedVertices = [False for vertex in range(vertices)]
    
    # While there are vertices that are not included in the MST, keep looking:
    while(False in selectedVertices):
        # We use the big number we created before as the possible minimum weight
        minimum = positiveInf

        # The starting vertex
        start = 0

        # The ending vertex
        end = 0
        for i in range(0,vertices):
            # If the vertex is part of the MST, look its relationships
            if selectedVertices[i]:
                # Again, we use the Symmetric Matrix as an advantage:
                for j in range(0,vertices):
                    # If the vertex analyzed have a path to the ending vertex AND its not included in the MST to avoid cycles)
                    if (not selectedVertices[j] and distance_matrixadj[i][j]>0):  
                        # If the weight path analyzed is less than the minimum of the MST
                        if distance_matrixadj[i][j] < minimum:
                            # Defines the new minimum weight, the starting vertex and the ending vertex
                            minimum = distance_matrixadj[i][j]
                            start, end = i, j
        
        
        #print("Start:", start, "END:",end)
        # Since we added the ending vertex to the MST, it's already selected:
        selectedVertices[end] = True

        # Filling the MST Adjacency Matrix fields:
        minSpanningTree_Matrix[start][end] = minimum
        
        # Initially, the minimum will be Inf if the first vertex is not connected with itself, but really it must be 0:
        if minimum == positiveInf:
            minSpanningTree_Matrix[start][end] = 0
            
        # Symmetric matrix, remember
        minSpanningTree_Matrix[end][start] = minSpanningTree_Matrix[start][end]

    # Show off:
    #print(mstMatrix)
    
    # Here the function ends
    return minSpanningTree_Matrix
###########################################################
    










