# -*- coding: utf-8 -*-
"""
prim version
"""

# -*- coding: utf-8 -*-
"""
REFS;https://stackabuse.com/graphs-in-python-minimum-spanning-trees-prims-algorithm/
"""
from utils import calc_distance,compute_dist_matrix,primsAlgorithm
from getpath_PrimAlgo import mainPath#getPath_afterPrimAlgo
import numpy as np
import math
import json
import matplotlib.pyplot as plt
import networkx as nx
import pylab

from tttt import Graphz
    
# Opening JSON file
f = open('NY69105.json',)
 
# returns JSON object as
# a dictionary
data = json.load(f)
 
#Adding the first equipment (starting point)
x_vals=[data["startEquipment"]["x"]]
y_vals=[data["startEquipment"]["y"]]



locs_length=len(data["locations"])

#Adding the rest of the equipment locations
for i in range(locs_length):
    x_vals.append(data["locations"][i]["x"])
    y_vals.append(data["locations"][i]["y"])

###

###


number_of_locations = len(x_vals)
        
#G: graph structure to plot (initialization) and color to plot in it
G = nx.Graph()
color_map = []

#Adding coordinates a list
coordinates_list = []
for i in range(len(x_vals)):
    tmp = [x_vals[i] , y_vals[i] ]
    
    coordinates_list.append(tmp)
    #G.add_node(i, pos=(x_vals[i],y_vals[i]))
    
    if i ==0:
        color_map.append('green')
    else:
        color_map.append('blue')




routes = (data["routes"])
dist_matrix=compute_dist_matrix(coordinates_list)


using_Routes_Constraints=True
#If true we use constraints  ("no support)" in the routes from the json file
if using_Routes_Constraints:
    ##Update distmatrix -> put negatives inside for route restrictions
    noSupport=[]
    for i in range(len(routes)):
        if routes[i]["type"]=="No Support":
            noSupport.append(routes[i])
    
    
    #print(noSupport[0])
    #print(noSupport[1])
    stockIndexRoutes=[]
    for r in noSupport:
        A=0
        Z=0
        for i in range(len(data["locations"])):
            loc = data["locations"][i]
            if r['locationA']== loc["uid"]:
                A=i
            elif r['locationZ']==loc["uid"]:
                Z=i
        
        stockIndexRoutes.append((A,Z))
    
    
    #print(stockIndexRoutes)
    
    for tupLocs in stockIndexRoutes:
        locA=tupLocs[0]
        locZ=tupLocs[1]
        dist_matrix[locA][locZ]=-1
        dist_matrix[locZ][locA]=-1
    
    

#Call to the Prims Algorithm fct; it returns an adjacency matrix // the Minimal Spanning Tree
adj_mat_MSP=primsAlgorithm(len(x_vals), dist_matrix)
#gg = Graphz(len(x_vals))
#gg.graph=dist_matrix
#adj_mat_MSP =gg.primMST()

#print(adj_mat_MSP)



tmpL = []
"""
for i in range(len(adj_mat_MSP)):
    print()
    print(dist_matrix[i])
    print()
    #print(adj_mat_MSP[i])
    
    print("----next----")
"""

for i in range(len(adj_mat_MSP)):
    for j in range(len(adj_mat_MSP[i])):
        #print(adj_mat_MSP[i][j])
        if adj_mat_MSP[i][j] not in tmpL:
            tmpL.append(adj_mat_MSP[i][j])
            
totl=0
for i in range(len(tmpL)):
    totl=tmpL[i]+totl
    print(">>",tmpL[i])    

print("total cable:",totl)
    

#convertion of the adj matrix to numpy array to a graph
G = nx.from_numpy_matrix(np.array(adj_mat_MSP))  
#Adding the coordinated to each point in the Graph Structure
for i in range(len(coordinates_list)):
    G.nodes[i]['pos'] = (coordinates_list[i][0],coordinates_list[i][1])


print()
print("NEW FCTS\n \n")
#getPath_afterPrimAlgo(adj_mat_MSP)
mainPath(adj_mat_MSP)

#Plotting:
fig, ax = plt.subplots(figsize=(35,35))
pos=nx.get_node_attributes(G,'pos')
pos = nx.spring_layout(G,pos=pos, k=0.15, iterations=50 )
#nx.draw(G, with_labels=True) .
nx.draw(G,pos,node_color=color_map,with_labels=True,ax=ax)

limits=plt.axis('on') # turns on axis
ax.tick_params(left=True, bottom=True, labelleft=True, labelbottom=True)


