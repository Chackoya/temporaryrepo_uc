# -*- coding: utf-8 -*-
"""
DFS
"""

def DFS( start, visited , vertices , graph, path,parent,boolTMP):
        # Print current node
        #print(start, end = ' ')
        L=path
        
        #print("st",start, "//", L)
        #boolTMP=False

        # Set current node as visited
        visited[start] = True
        #path=[]
        
        
        c=0
        for i in range(vertices):
            if (visited[i]):
                c += 1
        

        # If all the node is visited return
        if (c ==vertices):
            #L.append((parent,start))
            if boolTMP:
                L.append((parent,start))
                return
            else:
                return 
        else:
            L.append((parent,start))
        # For every node of the graph
        for i in range(vertices):
            #print("HERE ",i)
            # If some node is adjacent to the 
            # current node and it has not 
            # already been visited
            
            if (graph[start][i] !=0 and (not visited[i])):
                #path = path +[i]
                if c==vertices-1:
                    DFS(i, visited, vertices,graph,L,start, True)
                else:
                    DFS(i, visited, vertices,graph,L,start, False)
            
        
        #print("2ndprint:\n",L)
        for y in L:
            if (y[1] == start and y[0]!=-1):
                #if c==vertices-1:
                #    DFS(y[0], visited, vertices,graph,L,start,True)
                #else:
                DFS(y[0], visited, vertices,graph,L,start,False)
                #print("Y:",y)
                #L.append(y)
        #print("RETURNING",L)
        return L#+tmpL


    
    

def mainPath(adj_mat):
    
    #print(type(adj_mat))
    #dfsPrim(len(adj_mat),adj_mat)
    
    
    visited = [False] * len(adj_mat)
    
    p=DFS(0,  visited, len(adj_mat), adj_mat, [],-1,False)
    
    print("RES:",p)
    
    
    
    
    