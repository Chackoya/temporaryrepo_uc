# -*- coding: utf-8 -*-
"""
TESTING N° 1
"""
from utils import calc_distance,compute_dist_matrix
import numpy as np
import math
import json
import matplotlib.pyplot as plt
import networkx as nx
import pylab
# Opening JSON file
f = open('NY69105.json',)
 
# returns JSON object as
# a dictionary
data = json.load(f)
 
print(data.keys())


def find_next_point(L, index_current,list_visited_places):
    #print("HERE",L)
    #print("ind curre:",index_current)
    
    #print("Visited:",list_visited_places)
    #print()
    
    
    #sorting the list to get the min
    L_sorted = sorted(L)
    #print("sorted:",L_sorted)
    
    #Find the minimun and checking if visited
    for elem in L_sorted:
        #print(L.index(elem))
        if elem != L[index_current] and elem!=-1:
            if list_visited_places[L.index(elem)]==False:
                print(elem)
                return L.index(elem),elem
            
    return 0,0

x_vals=[data["startEquipment"]["x"]]
y_vals=[data["startEquipment"]["y"]]


#print(data["locations"][0])

for i in range(len(data["locations"])):
    x_vals.append(data["locations"][i]["x"])
    y_vals.append(data["locations"][i]["y"])

###

###


number_of_locations = len(x_vals)
        

#print(len(data["locations"]))
G = nx.Graph()
color_map = []

coordinates_list = []
for i in range(len(x_vals)):
    tmp = [x_vals[i] , y_vals[i] ]
    
    coordinates_list.append(tmp)
    G.add_node(i, pos=(x_vals[i],y_vals[i]))
    
    if i ==0:
        color_map.append('green')
    else:
        color_map.append('red')

#print(coordinates_list)
routes = (data["routes"])
dist_matrix=compute_dist_matrix(coordinates_list)



using_Routes_Constraints=False
#If true we use constraints  ("no support)" in the routes from the json file
if using_Routes_Constraints:
    ##Update distmatrix -> put negatives inside for route restrictions
    noSupport=[]
    for i in range(len(routes)):
        if routes[i]["type"]=="No Support":
            noSupport.append(routes[i])
    
    
    #print(noSupport[0])
    #print(noSupport[1])
    stockIndexRoutes=[]
    for r in noSupport:
        A=0
        Z=0
        for i in range(len(data["locations"])):
            loc = data["locations"][i]
            if r['locationA']== loc["uid"]:
                A=i
            elif r['locationZ']==loc["uid"]:
                Z=i
        
        stockIndexRoutes.append((A,Z))
    
    
    #print(stockIndexRoutes)
    
    for tupLocs in stockIndexRoutes:
        locA=tupLocs[0]
        locZ=tupLocs[1]
        dist_matrix[locA][locZ]=-1
        dist_matrix[locZ][locA]=-1


print("DIST MATRIX")
print()
for e in range(len(dist_matrix)):
    
    print(dist_matrix[e])
    print()

    

visited = [False for i in range((len(x_vals)))]
order_visit=[0]
visited[0]=True

cpt =1

totl = 0

for index_current_location in order_visit:
    
   # print(">>>>>>",order_visit)
    if cpt == len(x_vals):
        break
    
    next_point,dis = find_next_point(dist_matrix[index_current_location], index_current_location, visited)
    #while  visited[next_point] == False: 
        #next_point = find_next_point(dist_matrix[index_current_location], index_current_location)
    order_visit.append(next_point)
    totl=totl+dis
    visited[next_point] = True
    cpt=cpt+1
    
    print(index_current_location)
    G.add_edge(index_current_location,next_point)

print(order_visit)



print("DIST NORMALV1 :",totl)
ordered_xvals=[]
ordered_yvals=[]
for o in order_visit:
    ordered_xvals.append(x_vals[o])
    ordered_yvals.append(y_vals[o])
    
    

print()

"""
plt.figure(figsize=(15,15))
plt.plot(ordered_xvals,ordered_yvals)



#plt.plot(x_vals,y_vals)
#plt.plot(x_vals[1:-1],y_vals[1:-1],'or')
for i in range(number_of_locations):
    plt.plot(ordered_xvals[i],ordered_yvals[i],'ob')
    plt.annotate(str(order_visit[i]), (ordered_xvals[i], ordered_yvals[i]))
plt.plot(ordered_xvals[0], ordered_yvals[0], 'og')
plt.plot(ordered_xvals[-1], ordered_yvals[-1], 'or')

  """  


fig, ax = plt.subplots(figsize=(25,25))
#Create the graph G ; with nodes and edges based on the closest point with the help of the dist matrix
pos=nx.get_node_attributes(G,'pos')
pos = nx.spring_layout(G,pos=pos, k=0.1051, iterations=50 )#♂ fixed= pos.keys())
#pylab.figure(1,figsize=(25,25))
nx.draw(G,pos,node_color=color_map,with_labels=True,ax=ax)
limits=plt.axis('on') # turns on axis
ax.tick_params(left=True, bottom=True, labelleft=True, labelbottom=True)
#plt.savefig("graph.png", dpi=1000)

print(nx.is_connected(G))

