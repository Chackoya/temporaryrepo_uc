import networkx as nx

"""
import matplotlib.pyplot as plt
G = nx.Graph()
subax1 = plt.subplot(121)
nx.draw(G, with_labels=True, font_weight='bold')
subax2 = plt.subplot(122)
nx.draw_shell(G, nlist=[range(5, 10), range(5)], with_labels=True, font_weight='bold')"""


"""
l = [ (1 , 1) , (10, 0) , (155, 56) , (23,2)]


ll = sorted(l,key = lambda tup : tup[1])

print(ll)"""

from utils import calc_distance,compute_dist_matrix
import numpy as np
import math
import json
import matplotlib.pyplot as plt
import networkx as nx
import pylab

# Opening JSON file
f = open('NY69105.json',)
 
# returns JSON object as
# a dictionary
data = json.load(f)
 
print(data.keys())

x_vals=[data["startEquipment"]["x"]]
y_vals=[data["startEquipment"]["y"]]


#print(data["locations"][0])

for i in range(len(data["locations"])):
    x_vals.append(data["locations"][i]["x"])
    y_vals.append(data["locations"][i]["y"])

###

###


number_of_locations = len(x_vals)

coordinates_list = []
for i in range(len(x_vals)):
    tmp = [x_vals[i] , y_vals[i] ]
    
    coordinates_list.append(tmp)
    #G.add_node(i, pos=(x_vals[i],y_vals[i]))
    

dist_matrix=compute_dist_matrix(coordinates_list)


routes = (data["routes"])

print(len(routes))

print(number_of_locations)


noSupport=[]
for i in range(len(routes)):
    if routes[i]["type"]=="No Support":
        noSupport.append(routes[i])


print(noSupport[0])
print(noSupport[1])
stockIndexRoutes=[]
for r in noSupport:
    A=0
    Z=0
    for i in range(len(data["locations"])):
        loc = data["locations"][i]
        if r['locationA']== loc["uid"]:
            A=i
        elif r['locationZ']==loc["uid"]:
            Z=i
    
    stockIndexRoutes.append((A,Z))


print(stockIndexRoutes)
            

for tupLocs in stockIndexRoutes:
    locA=tupLocs[0]
    locZ=tupLocs[1]
    dist_matrix[locA][locZ]=-1
    dist_matrix[locZ][locA]=-1



print(dist_matrix[27][26])
print(dist_matrix[26][27])







